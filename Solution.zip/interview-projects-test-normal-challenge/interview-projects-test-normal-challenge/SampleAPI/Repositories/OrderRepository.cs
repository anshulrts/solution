﻿using Microsoft.EntityFrameworkCore;
using SampleAPI.Controllers;
using SampleAPI.Entities;
using SampleAPI.Requests;

namespace SampleAPI.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly SampleApiDbContext _context;
        private readonly ILogger<OrderRepository> _logger;

        public OrderRepository(SampleApiDbContext context, ILogger<OrderRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<List<Order>> GetAllOrders()
        {
            return await _context.Orders
                .OrderByDescending(order => order.EntryDate)
                .ToListAsync();
        }

        public async Task<int> AddNewOrder(Order newOrder)
        {
            _context.Orders.Add(newOrder);
            await _context.SaveChangesAsync();
            return newOrder.Id;
        }

        public async Task<List<Order>> GetRecentOrders()
        {
            return await _context.Orders
                .Where(order => order.EntryDate >= DateTime.Now.AddHours(-24) && !order.IsDeleted)
                .OrderByDescending(order => order.EntryDate)
                .ToListAsync();
        }

        public async Task<List<Order>> GetLastNOrders(int numberofdays)
        {
            var lastDate = SubtractBusinessDays(DateTime.Now, numberofdays);
            _logger.LogInformation($"Calculated datetime is : { lastDate }");


            return await _context.Orders
                .Where(order => order.EntryDate >= lastDate && !order.IsDeleted)
                .OrderByDescending(order => order.EntryDate)
                .ToListAsync();
        }

        public static DateTime SubtractBusinessDays(DateTime startDate, int numberofdays)
        {
            DateTime result = startDate;
            int daysSubtracted = 0;

            while (daysSubtracted < numberofdays)
            {
                result = result.AddDays(-1);
                if (result.DayOfWeek != DayOfWeek.Saturday && result.DayOfWeek != DayOfWeek.Sunday)
                {
                    daysSubtracted++;
                }
            }

            return result;
        }
    }
}
