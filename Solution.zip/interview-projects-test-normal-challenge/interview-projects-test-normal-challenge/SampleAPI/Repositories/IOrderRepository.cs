﻿using SampleAPI.Entities;
using SampleAPI.Requests;

namespace SampleAPI.Repositories
{
    public interface IOrderRepository
    {
        public Task<List<Order>> GetAllOrders();
        public Task<int> AddNewOrder(Order order);
        public Task<List<Order>> GetRecentOrders();
        public Task<List<Order>> GetLastNOrders(int numberofdays);

    }
}
