﻿using Microsoft.AspNetCore.Mvc;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;

namespace SampleAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private readonly ILogger<OrderController> _logger;

        public OrdersController(IOrderRepository orderRepository, ILogger<OrderRepository> logger)
        {
            _orderRepository = orderRepository;
            _logger = logger;
        }
 
        [HttpGet("/allorders")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<Order>>> GetOrders()
        {
            try
            {
                var allOrders = await _orderRepository.GetAllOrders();
                _logger.LogInformation("Successfully retrieved all orders.");
                return Ok(allOrders);
            }
            catch(Exception ex  )
            {
                _logger.LogError(ex, "An error occurred while retrieving all orders.");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while processing your request. Please try again later.");
            }
        }

        [HttpPost("/neworder")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<List<Order>>> PostOrder(Order newOrder)
        {
            // The description of this method mentioned that I have to use CreateOrderRequest class in order to add new Order.
            // However, the read.md file mentions that we are okay to remove any class in the scaffolded template.
            // I don't see the need to have CreateOrderRequest, we can call the Repository directly.
            try
            {
                if (ModelState.IsValid)
                {
                    var postedOrderId = await _orderRepository.AddNewOrder(newOrder);
                    return Ok(postedOrderId);
                }
                else
                {
                    return BadRequest("Invalid model state. Please check your input.");
                }
            }
            catch(Exception ex)
            {
                return BadRequest("An error occurred. Please try again later.");
            }
        }

        [HttpGet("/recentorders")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<Order>>> GetRecentOrders()
        {
            try
            {
                var allOrders = await _orderRepository.GetRecentOrders();
                _logger.LogInformation("Successfully retrieved all orders.");
                return Ok(allOrders);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving all orders.");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while processing your request. Please try again later.");
            }
        }

        [HttpGet("/lastnorders")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<Order>>> GetLastNOrders(int numberofdays)
        {
            try
            {
                if (numberofdays >= 0)
                {
                    var allOrders = await _orderRepository.GetLastNOrders(numberofdays);
                    _logger.LogInformation("Successfully retrieved all orders.");
                    return Ok(allOrders);
                }
                else
                {
                    return BadRequest("Please enter valid number of days..");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving all orders.");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while processing your request. Please try again later.");
            }
        }
    }
}
